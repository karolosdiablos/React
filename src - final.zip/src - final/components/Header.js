const Header = (() =>{
    return (
          <thead>
          <tr>
            <th>Imię</th>
            <th>Nazwisko</th>
            <th>Wynagrodzenie</th>
            <th>Skille</th>
            <th>Kasuj</th>
          </tr>
        </thead>
    )
  })

  export default Header;